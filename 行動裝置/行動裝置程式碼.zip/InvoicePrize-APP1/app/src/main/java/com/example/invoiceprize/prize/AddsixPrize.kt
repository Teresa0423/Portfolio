package com.example.invoiceprize.prize

import com.example.invoiceprize.Prize

class AddsixPrize : Prize() {
    init {
        name = "增開六獎"
        bonus = 200
    }
}