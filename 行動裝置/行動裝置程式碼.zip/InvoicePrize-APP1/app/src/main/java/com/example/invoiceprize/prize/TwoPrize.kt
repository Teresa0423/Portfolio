package com.example.invoiceprize.prize

import com.example.invoiceprize.Prize

class TwoPrize : Prize() {
    init {
        name = "二獎"
        bonus = 40000
    }
}