package com.example.invoiceprize.prize

import com.example.invoiceprize.Prize

class SixPrize : Prize() {
    init {
        name = "六獎"
        bonus = 200
    }
}