package com.example.invoiceprize

open class Prize {
    var name: String = "Test"
    var bonus = 0

//    fun Prize() {
//        super()
//    }
}